#!/bin/bash
yum --disablerepo=* localinstall -y ./ntfs-3g-2017.3.23-11.el7.x86_64.rpm
