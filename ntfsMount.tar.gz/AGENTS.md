# VisasVista Agent Rules

## Versioning And Changelog

- Any change that affects the public web shell must roll `website_build` and `pwa_build` through `python scripts/roll_web_version.py --scope website --scope project --note "..."`.
- Any change under `flight_api/` must roll `flight_api_build` and `project_build`.
- Any change under `utilities/` must roll `utilities_build` and `project_build`.
- If the change is specifically in `utilities/weather/`, also roll `utilities_weather_build`.
- If the change affects analytics, reports, or metrics under `utilities/`, also roll `utilities_metrics_build`.
- If the change affects operational scripts under `utilities/scripts/`, also roll `utilities_scripts_build`.
- If the underlying map or other static data feed consumed by the site changes, also roll `map_data_build`.
- Every version roll should append an entry to `docs/MASTER_CHANGELOG.md` using the `--note` flag.
- Frontend fetches for static JSON or static metadata must go through `window.VisasVistaVersioning` in `static/js/versioning.js`.
- Use `map_data_build` for map, country, state, and other static travel data feeds, and `utilities_weather_build` for exported weather JSON.
- If only the frontend consumer changes, roll `website` and `project`; if the dataset itself changes, also roll the corresponding data scope.

## Required Workflow

1. Make the code or docs change.
2. Run the version roll command for the affected scopes.
3. Confirm the relevant fields in `static/version.json` changed.
4. Confirm `docs/MASTER_CHANGELOG.md` has a matching entry.
